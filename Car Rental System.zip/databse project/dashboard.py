import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QPushButton, QLabel, QMessageBox
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

from manage_cars import ManageCarsUI
from manage_drivers import ManageDriversUI
from profile_settings import ProfileSettingsUI
from view_users import ViewUsersUI
from book_car import BookCarUI
from view_bookings import ViewBookingsUI
from return_car import ReturnCarUI


class DashboardWindow(QMainWindow):
    def __init__(self, user_id=None, is_admin=False, login_window=None):  # ✅ Now accepts admin flag
        super().__init__()
        self.logged_in_user_id = user_id
        self.is_admin = is_admin
        self.login_window = login_window
        self.setWindowTitle("FastCar Dashboard 🚘")
        self.setGeometry(200, 100, 800, 500)
        self.setStyleSheet("background-color: #1e1e2f; color: white;")
        self.init_ui()

    def init_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(20)

        title = QLabel("📋 Dashboard Menu")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        title.setStyleSheet("color: #00ffcc;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        self.buttons_info = {}

        if self.is_admin:
            self.buttons_info = {
                "Manage Cars": self.open_manage_cars,
                "Manage Drivers": self.open_manage_drivers,
                "View Users": self.open_view_users,
                "Book a Car": self.open_book_car,
                "View All Bookings": self.open_view_bookings,
                "Return a Car": self.open_return_car,
                "Profile Settings": self.open_profile_settings
            }
        else:
            self.buttons_info = {
                "Book a Car": self.open_book_car,
                "View All Bookings": self.open_view_bookings,
                "Return a Car": self.open_return_car,
                "Profile Settings": self.open_profile_settings
            }

        for text, action in self.buttons_info.items():
            btn = QPushButton(text)
            btn.setFixedWidth(200)
            btn.setStyleSheet("background-color: #2d2d44; color: white; padding: 10px; border-radius: 8px;")
            btn.setFont(QFont("Segoe UI", 10))
            btn.clicked.connect(action)
            layout.addWidget(btn, alignment=Qt.AlignCenter)

        logout_btn = QPushButton("Logout 🔒")
        logout_btn.setFixedWidth(200)
        logout_btn.setStyleSheet("background-color: #ff4444; color: white; padding: 10px; border-radius: 8px;")
        logout_btn.setFont(QFont("Segoe UI", 10, QFont.Bold))
        logout_btn.clicked.connect(self.logout)
        layout.addWidget(logout_btn, alignment=Qt.AlignCenter)

        main_widget.setLayout(layout)

    def open_manage_cars(self):
        self.manage_cars_window = ManageCarsUI(self)
        self.manage_cars_window.show()
        self.hide()

    def open_manage_drivers(self):
        self.manage_drivers_window = ManageDriversUI(self)
        self.manage_drivers_window.show()
        self.hide()

    def open_view_users(self):
        self.view_users_window = ViewUsersUI(self)
        self.view_users_window.show()
        self.hide()

    def open_book_car(self):
        self.book_car_window = BookCarUI(user_id=self.logged_in_user_id, dashboard_window=self)
        self.book_car_window.show()
        self.hide()

    def open_view_bookings(self):
        self.view_bookings_window = ViewBookingsUI(user_id=self.logged_in_user_id, dashboard_window=self)
        self.view_bookings_window.show()
        self.hide()

    def open_return_car(self):
        self.return_car_window = ReturnCarUI(user_id=self.logged_in_user_id, dashboard_window=self)
        self.return_car_window.show()
        self.hide()

    def open_profile_settings(self):
        self.profile_settings_window = ProfileSettingsUI(user_id=self.logged_in_user_id, dashboard_window=self)
        self.profile_settings_window.show()
        self.hide()

    def logout(self):
        reply = QMessageBox.question(self, "Logout", "Are you sure you want to logout?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.close()
            if self.login_window:
                self.login_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = DashboardWindow(user_id=1, is_admin=True)  # test admin view
    window.show()
    sys.exit(app.exec_())
