# main.py
import sys
import cx_Oracle
from PyQt5.QtWidgets import (
    QApplication, QDialog, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from register_window import RegisterUI
from dashboard import DashboardWindow

DB_USERNAME = "FARAZ4"
DB_PASSWORD = "gudboy"
DB_DSN = "localhost/xe"

class LoginUI(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Car Rental Login")
        self.setFixedSize(400, 300)
        self.setStyleSheet("background-color: #1e1e2f; color: white;")
        self.init_ui()

    def init_ui(self):
        title = QLabel("Welcome to FastCar 🚗")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #00ffcc;")

        user_label = QLabel("Username (Full Name):")
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Enter your full name")

        pass_label = QLabel("Password:")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setPlaceholderText("Enter your password")

        self.login_btn = QPushButton("Login as User")
        self.login_btn.clicked.connect(self.handle_user_login)

        self.admin_login_btn = QPushButton("Login as Admin")
        self.admin_login_btn.clicked.connect(self.handle_admin_login)

        self.register_btn = QPushButton("Register")
        self.register_btn.clicked.connect(self.open_register)

        btn_layout = QHBoxLayout()
        btn_layout.addWidget(self.login_btn)
        btn_layout.addWidget(self.admin_login_btn)

        layout = QVBoxLayout()
        layout.addWidget(title)
        layout.addSpacing(15)
        layout.addWidget(user_label)
        layout.addWidget(self.username_input)
        layout.addWidget(pass_label)
        layout.addWidget(self.password_input)
        layout.addSpacing(10)
        layout.addLayout(btn_layout)
        layout.addWidget(self.register_btn)

        self.setLayout(layout)

    def handle_user_login(self):
        username = self.username_input.text().strip()
        password = self.password_input.text()

        if not username or not password:
            QMessageBox.warning(self, "Oops!", "Please enter username and password.")
            return

        try:
            conn = cx_Oracle.connect(DB_USERNAME, DB_PASSWORD, DB_DSN)
            cursor = conn.cursor()

            cursor.execute("SELECT USER_ID FROM USERS WHERE FULL_NAME = :u AND PASSWORD = :p", [username, password])
            row = cursor.fetchone()

            if row:
                user_id = row[0]
                QMessageBox.information(self, "Welcome!", f"Welcome {username}, you logged in as User.")
                self.dashboard = DashboardWindow(user_id=user_id, is_admin=False, login_window=self)
                self.dashboard.show()
                self.close()
            else:
                QMessageBox.warning(self, "Invalid", "Invalid user credentials.")

            cursor.close()
            conn.close()
        except cx_Oracle.DatabaseError as e:
            QMessageBox.critical(self, "DB Error", str(e))

    def handle_admin_login(self):
        username = self.username_input.text().strip()
        password = self.password_input.text()

        if username == "admin" and password == "admin123":
            QMessageBox.information(self, "Welcome!", "Welcome admin, you logged in as Admin.")
            self.dashboard = DashboardWindow(user_id=None, is_admin=True, login_window=self)  # Admin mode
            self.dashboard.show()
            self.close()
        else:
            QMessageBox.warning(self, "Invalid", "Invalid admin credentials.")

    def open_register(self):
        self.register_window = RegisterUI()
        self.register_window.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = LoginUI()
    window.show()
    sys.exit(app.exec_())
