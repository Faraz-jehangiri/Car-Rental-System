import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, QPushButton,
    QLineEdit, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
import cx_Oracle


class ProfileSettingsUI(QWidget):
    def __init__(self, user_id, dashboard_window=None):
        super().__init__()
        self.user_id = user_id
        self.dashboard_window = dashboard_window
        self.setWindowTitle("👤 Profile Settings")
        self.setGeometry(250, 100, 500, 400)
        self.setStyleSheet("background-color: #1e1e2f; color: white;")
        self.conn = cx_Oracle.connect("FARAZ4", "gudboy", "localhost/XE")
        self.init_ui()

    def init_ui(self):
        self.layout = QVBoxLayout()

        title = QLabel("⚙️ Profile Settings")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        title.setStyleSheet("color: #00ffcc;")
        title.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(title)

        # Buttons for actions
        view_btn = QPushButton("📄 View Profile Info")
        view_btn.setStyleSheet("background-color: #444; padding: 8px; border-radius: 5px;")
        view_btn.clicked.connect(self.view_profile_info)
        self.layout.addWidget(view_btn)

        update_btn = QPushButton("🔐 Update Password")
        update_btn.setStyleSheet("background-color: #444; padding: 8px; border-radius: 5px;")
        update_btn.clicked.connect(self.show_update_password)
        self.layout.addWidget(update_btn)

        back_btn = QPushButton("⬅ Back to Dashboard")
        back_btn.setStyleSheet("background-color: #555555; padding: 10px; border-radius: 5px;")
        back_btn.clicked.connect(self.go_back)
        self.layout.addWidget(back_btn)

        self.setLayout(self.layout)

    def view_profile_info(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT FULL_NAME, EMAIL FROM USERS WHERE USER_ID = :1", (self.user_id,))
        result = cursor.fetchone()
        cursor.close()

        if result:
            name, email = result
            QMessageBox.information(self, "Your Info", f"👤 Name: {name}\n📧 Email: {email}")
        else:
            QMessageBox.warning(self, "Error", "User not found.")

    def show_update_password(self):
        # Clear layout
        for i in reversed(range(self.layout.count())):
            widget = self.layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        title = QLabel("🔐 Update Your Password")
        title.setFont(QFont("Segoe UI", 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #00ffcc;")
        self.layout.addWidget(title)

        self.new_pass_input = QLineEdit()
        self.new_pass_input.setEchoMode(QLineEdit.Password)
        self.new_pass_input.setPlaceholderText("Enter new password")
        self.new_pass_input.setStyleSheet("background-color: #2d2d44; color: white;")
        self.layout.addWidget(self.new_pass_input)

        update_btn = QPushButton("✅ Update Password")
        update_btn.setStyleSheet("background-color: #00cc66; padding: 10px; border-radius: 5px;")
        update_btn.clicked.connect(self.update_password)
        self.layout.addWidget(update_btn)

        back_btn = QPushButton("⬅ Back to Profile Menu")
        back_btn.setStyleSheet("background-color: #555555; padding: 10px; border-radius: 5px;")
        back_btn.clicked.connect(self.reset_ui)
        self.layout.addWidget(back_btn)

    def update_password(self):
        new_password = self.new_pass_input.text().strip()
        if not new_password:
            QMessageBox.warning(self, "Error", "Password cannot be empty.")
            return

        cursor = self.conn.cursor()
        cursor.execute("UPDATE USERS SET PASSWORD = :1 WHERE USER_ID = :2", (new_password, self.user_id))
        self.conn.commit()
        cursor.close()
        QMessageBox.information(self, "Success", "Your password was updated.")
        self.reset_ui()

    def reset_ui(self):
        # Clear layout items only, not the layout itself
        for i in reversed(range(self.layout.count())):
            widget = self.layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        # Re-add buttons manually here just like init_ui
        title = QLabel("⚙️ Profile Settings")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        title.setStyleSheet("color: #00ffcc;")
        title.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(title)

        view_btn = QPushButton("📄 View Profile Info")
        view_btn.setStyleSheet("background-color: #444; padding: 8px; border-radius: 5px;")
        view_btn.clicked.connect(self.view_profile_info)
        self.layout.addWidget(view_btn)

        update_btn = QPushButton("🔐 Update Password")
        update_btn.setStyleSheet("background-color: #444; padding: 8px; border-radius: 5px;")
        update_btn.clicked.connect(self.show_update_password)
        self.layout.addWidget(update_btn)

        back_btn = QPushButton("⬅ Back to Dashboard")
        back_btn.setStyleSheet("background-color: #555555; padding: 10px; border-radius: 5px;")
        back_btn.clicked.connect(self.go_back)
        self.layout.addWidget(back_btn)

    def go_back(self):
        self.close()
        if self.dashboard_window:
            self.dashboard_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    user_id = 5  # 👈 Change this during actual login
    window = ProfileSettingsUI(user_id)
    window.show()
    sys.exit(app.exec_())
