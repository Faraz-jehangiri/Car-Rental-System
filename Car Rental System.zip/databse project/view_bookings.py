from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem, QPushButton, QMessageBox
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
import cx_Oracle

class ViewBookingsUI(QWidget):
    def __init__(self, user_id, dashboard_window=None):
        super().__init__()
        self.logged_in_user_id = user_id
        self.dashboard_window = dashboard_window
        self.setWindowTitle("📄 Your Bookings")
        self.setGeometry(250, 100, 700, 400)
        self.setStyleSheet("background-color: #1e1e2f; color: white;")
        self.conn = cx_Oracle.connect("FARAZ4", "gudboy", "localhost/XE")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        title = QLabel("🧾 Your Booking History")
        title.setFont(QFont("Segoe UI", 14, QFont.Bold))
        title.setStyleSheet("color: #00ffcc;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        self.table = QTableWidget()
        self.table.setStyleSheet("background-color: #2d2d44; color: black; gridline-color: #444;")
        layout.addWidget(self.table)

        back_btn = QPushButton("⬅ Back to Dashboard")
        back_btn.setStyleSheet("background-color: #00ffcc; color: black; padding: 10px; border-radius: 5px;")
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)

        self.setLayout(layout)
        self.load_bookings()

    def load_bookings(self):
        cursor = self.conn.cursor()
        try:
            query = """
                SELECT 
                    B.BOOKING_ID, 
                    C.BRAND || ' ' || C.MODEL AS CAR, 
                    NVL(D.NAME, 'No Driver') AS DRIVER,
                    TO_CHAR(B.BOOKING_DATE, 'YYYY-MM-DD') AS BOOKING_DATE,
                    B.WITH_DRIVER
                FROM BOOKINGS B
                JOIN CARS C ON B.CAR_ID = C.CAR_ID
                LEFT JOIN DRIVERS D ON B.DRIVER_ID = D.DRIVER_ID
                WHERE B.USER_ID = :1
                ORDER BY B.BOOKING_DATE DESC
            """
            cursor.execute(query, (self.logged_in_user_id,))
            rows = cursor.fetchall()

            self.table.setColumnCount(5)
            self.table.setRowCount(len(rows))
            self.table.setHorizontalHeaderLabels(["Booking ID", "Car", "Driver", "Date", "With Driver"])

            for row_idx, row in enumerate(rows):
                for col_idx, value in enumerate(row):
                    item = QTableWidgetItem(str(value))
                    item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                    self.table.setItem(row_idx, col_idx, item)

            if not rows:
                QMessageBox.information(self, "No Bookings", "You have not made any bookings yet.")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load bookings:\n{str(e)}")
        finally:
            cursor.close()

    def go_back(self):
        self.close()
        if self.dashboard_window:
            self.dashboard_window.show()
