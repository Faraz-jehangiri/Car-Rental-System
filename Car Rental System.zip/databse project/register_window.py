import sys
import cx_Oracle
from PyQt5.QtWidgets import (
    QApplication, QDialog, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

DB_USERNAME = "FARAZ4"
DB_PASSWORD = "gudboy"
DB_DSN = "localhost/xe"

class RegisterUI(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("FastCar Register")
        self.setFixedSize(400, 400)
        self.setStyleSheet("background-color: #1e1e2f; color: white;")
        self.init_ui()

    def init_ui(self):
        title = QLabel("Create your FastCar account 🚗")
        title.setFont(QFont("Segoe UI", 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #00ffcc;")

        self.name_label = QLabel("Full Name:")
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Enter your full name")
        self.name_input.setStyleSheet("padding: 5px; border-radius: 4px;")

        self.email_label = QLabel("Email:")
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("Enter your email")
        self.email_input.setStyleSheet("padding: 5px; border-radius: 4px;")

        self.password_label = QLabel("Password:")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setPlaceholderText("Enter password")
        self.password_input.setStyleSheet("padding: 5px; border-radius: 4px;")

        self.confirm_label = QLabel("Confirm Password:")
        self.confirm_input = QLineEdit()
        self.confirm_input.setEchoMode(QLineEdit.Password)
        self.confirm_input.setPlaceholderText("Confirm password")
        self.confirm_input.setStyleSheet("padding: 5px; border-radius: 4px;")

        self.register_btn = QPushButton("Register")
        self.register_btn.setStyleSheet("background-color: #00ffcc; padding: 8px; border-radius: 5px;")
        self.register_btn.clicked.connect(self.handle_register)

        self.back_btn = QPushButton("Back to Login")
        self.back_btn.setStyleSheet("background-color: #ffaa00; padding: 8px; border-radius: 5px;")
        self.back_btn.clicked.connect(self.close)

        layout = QVBoxLayout()
        layout.addWidget(title)
        layout.addSpacing(10)
        layout.addWidget(self.name_label)
        layout.addWidget(self.name_input)
        layout.addWidget(self.email_label)
        layout.addWidget(self.email_input)
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        layout.addWidget(self.confirm_label)
        layout.addWidget(self.confirm_input)
        layout.addSpacing(10)
        layout.addWidget(self.register_btn)
        layout.addWidget(self.back_btn)

        self.setLayout(layout)

    def handle_register(self):
        name = self.name_input.text().strip()
        email = self.email_input.text().strip()
        password = self.password_input.text()
        confirm = self.confirm_input.text()

        if not name or not email or not password or not confirm:
            QMessageBox.warning(self, "Oops!", "All fields are required.")
            return

        if password != confirm:
            QMessageBox.warning(self, "Mismatch", "Passwords do not match.")
            return

        try:
            conn = cx_Oracle.connect(DB_USERNAME, DB_PASSWORD, DB_DSN)
            cursor = conn.cursor()

            cursor.execute("SELECT * FROM USERS WHERE EMAIL = :e", [email])
            if cursor.fetchone():
                QMessageBox.warning(self, "Exists", "Email already registered.")
                cursor.close()
                conn.close()
                return

            cursor.execute(
                "INSERT INTO USERS (FULL_NAME, EMAIL, PASSWORD) VALUES (:n, :e, :p)",
                [name, email, password]
            )
            conn.commit()

            QMessageBox.information(self, "Success", "Account created successfully!")
            cursor.close()
            conn.close()
            self.close()

        except cx_Oracle.DatabaseError as e:
            QMessageBox.critical(self, "DB Error", str(e))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = RegisterUI()
    window.show()
    sys.exit(app.exec_())
