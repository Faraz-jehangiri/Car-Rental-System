import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel,
    QPushButton, QComboBox, QDateEdit, QMessageBox
)
from PyQt5.QtCore import Qt, QDate
from PyQt5.QtGui import QFont
import cx_Oracle


class BookCarUI(QWidget):
    def __init__(self, user_id, dashboard_window=None):
        super().__init__()
        self.dashboard_window = dashboard_window
        self.logged_in_user_id = user_id
        self.setWindowTitle("Book a Car 🚗")
        self.setGeometry(250, 100, 500, 450)
        self.setStyleSheet("background-color: #1e1e2f; color: white;")
        self.conn = cx_Oracle.connect("FARAZ4", "gudboy", "localhost/XE")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        title = QLabel("🚘 Book a Car")
        title.setFont(QFont("Segoe UI", 18, QFont.Bold))
        title.setStyleSheet("color: #00ffcc; margin-bottom: 20px;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Car selection
        car_label = QLabel("🚗 Select Car:")
        car_label.setStyleSheet("color: #ffcc00; font-weight: bold;")
        layout.addWidget(car_label)

        self.car_dropdown = QComboBox()
        self.car_dropdown.setStyleSheet("""
            background-color: #2d2d44; color: white;
            padding: 6px; border-radius: 4px;
        """)
        layout.addWidget(self.car_dropdown)

        # Driver preference
        driver_label = QLabel("🧍 Want a Driver? (Extra Charges)")
        driver_label.setStyleSheet("color: #ffcc00; font-weight: bold;")
        layout.addWidget(driver_label)

        self.want_driver_dropdown = QComboBox()
        self.want_driver_dropdown.setStyleSheet("""
            background-color: #2d2d44; color: white;
            padding: 6px; border-radius: 4px;
        """)
        self.want_driver_dropdown.addItems(["No", "Yes"])
        self.want_driver_dropdown.currentIndexChanged.connect(self.toggle_driver_dropdown)
        layout.addWidget(self.want_driver_dropdown)

        # Driver selection
        select_driver_label = QLabel("👨‍✈️ Select Driver:")
        select_driver_label.setStyleSheet("color: #ffcc00; font-weight: bold;")
        layout.addWidget(select_driver_label)

        self.driver_dropdown = QComboBox()
        self.driver_dropdown.setStyleSheet("""
            background-color: #2d2d44; color: white;
            padding: 6px; border-radius: 4px;
        """)
        self.driver_dropdown.hide()
        layout.addWidget(self.driver_dropdown)

        # Booking date
        date_label = QLabel("📅 Select Booking Date:")
        date_label.setStyleSheet("color: #ffcc00; font-weight: bold;")
        layout.addWidget(date_label)

        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(QDate.currentDate())
        self.date_edit.setStyleSheet("""
            background-color: #2d2d44; color: white;
            padding: 6px; border-radius: 4px;
        """)
        layout.addWidget(self.date_edit)

        # Buttons
        book_btn = QPushButton("✅ Book Now")
        book_btn.setStyleSheet("""
            background-color: #00cc66; padding: 10px;
            border-radius: 6px; font-weight: bold;
        """)
        book_btn.clicked.connect(self.book_now)
        layout.addWidget(book_btn)

        back_btn = QPushButton("↩️ Back to Dashboard")
        back_btn.setStyleSheet("""
            background-color: #555555; padding: 10px;
            border-radius: 6px; font-weight: bold;
        """)
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)

        self.setLayout(layout)
        self.load_data()

    def toggle_driver_dropdown(self):
        if self.want_driver_dropdown.currentText().lower() == "yes":
            self.driver_dropdown.show()
        else:
            self.driver_dropdown.hide()

    def load_data(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT CAR_ID, BRAND, MODEL FROM CARS WHERE AVAILABILITY = 'yes'")
        cars = cursor.fetchall()
        self.car_dropdown.clear()
        for car_id, brand, model in cars:
            self.car_dropdown.addItem(f"{car_id} - {brand} {model}", car_id)

        cursor.execute("SELECT DRIVER_ID, NAME FROM DRIVERS WHERE AVAILABILITY = 'yes'")
        drivers = cursor.fetchall()
        self.driver_dropdown.clear()
        for driver_id, name in drivers:
            self.driver_dropdown.addItem(f"{driver_id} - {name}", driver_id)

        cursor.close()

    def book_now(self):
        car_id = self.car_dropdown.currentData()
        wants_driver = self.want_driver_dropdown.currentText().lower() == "yes"
        driver_id = self.driver_dropdown.currentData() if wants_driver else None
        with_driver = "yes" if wants_driver else "no"
        cost = 4500 if wants_driver else 3000
        date_str = self.date_edit.date().toString("yyyy-MM-dd")

        if with_driver == "yes" and driver_id is None:
            QMessageBox.warning(self, "Booking Error", "You selected 'Yes' for driver but didn't pick a valid driver.")
            return

        cursor = self.conn.cursor()
        try:
            cursor.execute("SELECT COUNT(*) FROM USERS WHERE USER_ID = :1", (self.logged_in_user_id,))
            if cursor.fetchone()[0] == 0:
                QMessageBox.critical(self, "Booking Error", f"User ID {self.logged_in_user_id} does not exist.")
                return

            if driver_id is None:
                query = """
                    INSERT INTO BOOKINGS (BOOKING_ID, USER_ID, CAR_ID, BOOKING_DATE, WITH_DRIVER)
                    VALUES (BOOKING_SEQ.NEXTVAL, :1, :2, TO_DATE(:3, 'YYYY-MM-DD'), :4)
                """
                params = (self.logged_in_user_id, car_id, date_str, with_driver)
            else:
                query = """
                    INSERT INTO BOOKINGS (BOOKING_ID, USER_ID, CAR_ID, DRIVER_ID, BOOKING_DATE, WITH_DRIVER)
                    VALUES (BOOKING_SEQ.NEXTVAL, :1, :2, :3, TO_DATE(:4, 'YYYY-MM-DD'), :5)
                """
                params = (self.logged_in_user_id, car_id, driver_id, date_str, with_driver)

            # 🧠 Logging just in case
            print(">>> Running Query:")
            print(query)
            print(">>> With Params:")
            print(params)

            cursor.execute(query, params)

            cursor.execute("UPDATE CARS SET AVAILABILITY = 'no' WHERE CAR_ID = :1", (car_id,))
            if driver_id:
                cursor.execute("UPDATE DRIVERS SET AVAILABILITY = 'no' WHERE DRIVER_ID = :1", (driver_id,))

            self.conn.commit()
            QMessageBox.information(self, "Booking Successful", f"Car booked successfully!\nEstimated Cost: PKR {cost}")
            self.go_back()

        except Exception as e:
            self.conn.rollback()
            QMessageBox.critical(self, "Error", f"Booking Failed:\n{str(e)}")
        finally:
            cursor.close()

    def go_back(self):
        self.close()
        if self.dashboard_window:
            self.dashboard_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # 👇 Test mode ON only if you're running this file directly
    TESTING_MODE = True
    TEST_USER_ID = 5

    if TESTING_MODE:
        window = BookCarUI(user_id=TEST_USER_ID)
        window.show()
    else:
        QMessageBox.critical(None, "Access Denied", "Please launch this screen through the dashboard after login.")

    sys.exit(app.exec_())
