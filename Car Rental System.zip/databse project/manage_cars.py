import cx_Oracle
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QPushButton, QMessageBox, QLineEdit, QHBoxLayout, QComboBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

DB_USERNAME = "FARAZ4"
DB_PASSWORD = "gudboy"
DB_DSN = "localhost/xe"

class ManageCarsUI(QWidget):
    def __init__(self, dashboard_ref=None):
        super().__init__()
        self.dashboard_ref = dashboard_ref
        self.setWindowTitle("Manage Cars")
        self.setStyleSheet("background-color: #1e1e2f; color: white;")
        self.setMinimumSize(600, 400)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        title = QLabel("🚘 Manage Cars")
        title.setFont(QFont("Segoe UI", 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #00ffcc;")
        layout.addWidget(title)

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Car ID", "Model", "Brand", "Reg No", "Availability"])
        self.table.setStyleSheet("background-color: white; color: black;")
        layout.addWidget(self.table)

        input_layout = QHBoxLayout()
        self.model_input = QLineEdit()
        self.model_input.setPlaceholderText("Model")
        self.brand_input = QLineEdit()
        self.brand_input.setPlaceholderText("Brand")
        self.reg_input = QLineEdit()
        self.reg_input.setPlaceholderText("Reg No")
        self.avail_input = QComboBox()
        self.avail_input.addItems(["yes", "no"])

        input_layout.addWidget(self.model_input)
        input_layout.addWidget(self.brand_input)
        input_layout.addWidget(self.reg_input)
        input_layout.addWidget(self.avail_input)
        layout.addLayout(input_layout)

        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Car")
        delete_btn = QPushButton("Delete Selected Car")
        add_btn.setStyleSheet("background-color: #00cc66; padding: 6px;")
        delete_btn.setStyleSheet("background-color: #cc0000; padding: 6px;")
        add_btn.clicked.connect(self.add_car)
        delete_btn.clicked.connect(self.delete_car)

        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(delete_btn)
        layout.addLayout(btn_layout)

        back_btn = QPushButton("⬅ Back to Dashboard")
        back_btn.setStyleSheet("background-color: #4444cc; padding: 6px;")
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)

        self.setLayout(layout)
        self.load_cars()

    def connect_db(self):
        return cx_Oracle.connect(DB_USERNAME, DB_PASSWORD, DB_DSN)

    def load_cars(self):
        try:
            conn = self.connect_db()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM CARS")
            rows = cursor.fetchall()
            self.table.setRowCount(0)
            for row_data in rows:
                row_index = self.table.rowCount()
                self.table.insertRow(row_index)
                for col_index, data in enumerate(row_data):
                    self.table.setItem(row_index, col_index, QTableWidgetItem(str(data)))
            cursor.close()
            conn.close()
        except cx_Oracle.DatabaseError as e:
            QMessageBox.critical(self, "Error", str(e))

    def add_car(self):
        model = self.model_input.text().strip()
        brand = self.brand_input.text().strip()
        reg = self.reg_input.text().strip()
        avail = self.avail_input.currentText()

        if not all([model, brand, reg, avail]):
            QMessageBox.warning(self, "Missing Data", "Please fill in all fields.")
            return

        try:
            conn = self.connect_db()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO CARS (MODEL, BRAND, REGISTRATION_NO, AVAILABILITY)
                VALUES (:model, :brand, :reg, :avail)
            """, {
                "model": model,
                "brand": brand,
                "reg": reg,
                "avail": avail
            })
            conn.commit()
            cursor.close()
            conn.close()

            self.model_input.clear()
            self.brand_input.clear()
            self.reg_input.clear()
            self.avail_input.setCurrentIndex(0)

            self.load_cars()
            QMessageBox.information(self, "Success", "Car added successfully.")
        except cx_Oracle.DatabaseError as e:
            QMessageBox.critical(self, "DB Error", str(e))

    def delete_car(self):
        selected_row = self.table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "No Selection", "Select a car to delete.")
            return

        car_id = self.table.item(selected_row, 0).text()
        confirm = QMessageBox.question(self, "Delete", f"Delete car ID {car_id}?",
                                       QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            try:
                conn = self.connect_db()
                cursor = conn.cursor()
                cursor.execute("DELETE FROM CARS WHERE CAR_ID = :car_id", {"car_id": car_id})
                conn.commit()
                cursor.close()
                conn.close()
                self.load_cars()
                QMessageBox.information(self, "Deleted", "Car deleted.")
            except cx_Oracle.DatabaseError as e:
                QMessageBox.critical(self, "DB Error", str(e))

    def go_back(self):
        self.close()
        if self.dashboard_ref:
            self.dashboard_ref.show()
