import cx_Oracle
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QPushButton, QMessageBox, QHBoxLayout
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

# DB config
DB_USERNAME = "FARAZ4"
DB_PASSWORD = "gudboy"
DB_DSN = "localhost/xe"

class ViewUsersUI(QWidget):
    def __init__(self, dashboard_ref=None):
        super().__init__()
        self.dashboard_ref = dashboard_ref
        self.setWindowTitle("View Users")
        self.setStyleSheet("background-color: #1e1e2f; color: white;")
        self.setMinimumSize(600, 400)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        title = QLabel("👥 Registered Users")
        title.setFont(QFont("Segoe UI", 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #00ffcc;")
        layout.addWidget(title)

        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["User ID", "Full Name", "Email", "Password"])
        self.table.setStyleSheet("background-color: white; color: black;")
        layout.addWidget(self.table)

        btn_layout = QHBoxLayout()
        delete_btn = QPushButton("Delete Selected User")
        delete_btn.setStyleSheet("background-color: #cc0000; padding: 6px;")
        delete_btn.clicked.connect(self.delete_user)

        back_btn = QPushButton("Back to Dashboard")
        back_btn.setStyleSheet("background-color: #333366; padding: 6px; color: white;")
        back_btn.clicked.connect(self.go_back)

        btn_layout.addWidget(delete_btn)
        btn_layout.addWidget(back_btn)
        layout.addLayout(btn_layout)

        self.setLayout(layout)
        self.load_users()

    def connect_db(self):
        return cx_Oracle.connect(DB_USERNAME, DB_PASSWORD, DB_DSN)

    def load_users(self):
        try:
            conn = self.connect_db()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM USERS")
            rows = cursor.fetchall()
            self.table.setRowCount(0)
            for row_data in rows:
                row_index = self.table.rowCount()
                self.table.insertRow(row_index)
                for col_index, data in enumerate(row_data):
                    self.table.setItem(row_index, col_index, QTableWidgetItem(str(data)))
            cursor.close()
            conn.close()
        except cx_Oracle.DatabaseError as e:
            QMessageBox.critical(self, "Error", str(e))

    def delete_user(self):
        selected_row = self.table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "No Selection", "Select a user to delete.")
            return

        user_id = self.table.item(selected_row, 0).text()
        confirm = QMessageBox.question(self, "Delete", f"Delete User ID {user_id}?",
                                       QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            try:
                conn = self.connect_db()
                cursor = conn.cursor()
                cursor.execute("DELETE FROM USERS WHERE USER_ID = :user_id", {"user_id": user_id})
                conn.commit()
                cursor.close()
                conn.close()
                self.load_users()
                QMessageBox.information(self, "Deleted", "User deleted.")
            except cx_Oracle.DatabaseError as e:
                QMessageBox.critical(self, "DB Error", str(e))

    def go_back(self):
        self.close()
        if self.dashboard_ref:
            self.dashboard_ref.show()

if __name__ == "__main__":
    from PyQt5.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    window = ViewUsersUI()
    window.show()
    sys.exit(app.exec_())
