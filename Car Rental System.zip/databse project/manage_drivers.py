import cx_Oracle
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QPushButton, QMessageBox, QLineEdit, QHBoxLayout, QComboBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

DB_USERNAME = "FARAZ4"
DB_PASSWORD = "gudboy"
DB_DSN = "localhost/xe"

class ManageDriversUI(QWidget):
    def __init__(self, parent_dashboard=None):
        super().__init__()
        self.parent_dashboard = parent_dashboard
        self.setWindowTitle("Manage Drivers")
        self.setStyleSheet("background-color: #1e1e2f; color: white;")
        self.setMinimumSize(600, 400)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        title = QLabel("🧍 Manage Drivers")
        title.setFont(QFont("Segoe UI", 14, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #00ffcc;")
        layout.addWidget(title)

        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Driver ID", "Name", "Phone", "Availability"])
        self.table.setStyleSheet("background-color: white; color: black;")
        layout.addWidget(self.table)

        input_layout = QHBoxLayout()
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Name")
        self.phone_input = QLineEdit()
        self.phone_input.setPlaceholderText("Phone")
        self.avail_input = QComboBox()
        self.avail_input.addItems(["yes", "no"])

        input_layout.addWidget(self.name_input)
        input_layout.addWidget(self.phone_input)
        input_layout.addWidget(self.avail_input)
        layout.addLayout(input_layout)

        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Driver")
        delete_btn = QPushButton("Delete Selected Driver")
        back_btn = QPushButton("Back to Dashboard")
        add_btn.setStyleSheet("background-color: #00cc66; padding: 6px;")
        delete_btn.setStyleSheet("background-color: #cc0000; padding: 6px;")
        back_btn.setStyleSheet("background-color: #333366; padding: 6px; color: white;")

        add_btn.clicked.connect(self.add_driver)
        delete_btn.clicked.connect(self.delete_driver)
        back_btn.clicked.connect(self.back_to_dashboard)

        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(delete_btn)
        btn_layout.addWidget(back_btn)
        layout.addLayout(btn_layout)

        self.setLayout(layout)
        self.load_drivers()

    def connect_db(self):
        return cx_Oracle.connect(DB_USERNAME, DB_PASSWORD, DB_DSN)

    def load_drivers(self):
        try:
            conn = self.connect_db()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM DRIVERS")
            rows = cursor.fetchall()
            self.table.setRowCount(0)
            for row_data in rows:
                row_index = self.table.rowCount()
                self.table.insertRow(row_index)
                for col_index, data in enumerate(row_data):
                    self.table.setItem(row_index, col_index, QTableWidgetItem(str(data)))
            cursor.close()
            conn.close()
        except cx_Oracle.DatabaseError as e:
            QMessageBox.critical(self, "Error", str(e))

    def add_driver(self):
        name = self.name_input.text().strip()
        phone = self.phone_input.text().strip()
        avail = self.avail_input.currentText()

        if not all([name, phone, avail]):
            QMessageBox.warning(self, "Missing Data", "Please fill in all fields.")
            return

        try:
            conn = self.connect_db()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO DRIVERS (NAME, PHONE, AVAILABILITY)
                VALUES (:name, :phone, :avail)
            """, {
                'name': name,
                'phone': phone,
                'avail': avail
            })
            conn.commit()
            cursor.close()
            conn.close()
            self.name_input.clear()
            self.phone_input.clear()
            self.avail_input.setCurrentIndex(0)
            self.load_drivers()
            QMessageBox.information(self, "Success", "Driver added successfully.")
        except cx_Oracle.DatabaseError as e:
            QMessageBox.critical(self, "DB Error", str(e))

    def delete_driver(self):
        selected_row = self.table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "No Selection", "Select a driver to delete.")
            return

        driver_id = self.table.item(selected_row, 0).text()
        confirm = QMessageBox.question(self, "Delete", f"Delete driver ID {driver_id}?",
                                       QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            try:
                conn = self.connect_db()
                cursor = conn.cursor()
                cursor.execute("DELETE FROM DRIVERS WHERE DRIVER_ID = :driver_id", {'driver_id': driver_id})
                conn.commit()
                cursor.close()
                conn.close()
                self.load_drivers()
                QMessageBox.information(self, "Deleted", "Driver deleted.")
            except cx_Oracle.DatabaseError as e:
                QMessageBox.critical(self, "DB Error", str(e))

    def back_to_dashboard(self):
        self.close()
        if self.parent_dashboard:
            self.parent_dashboard.show()
