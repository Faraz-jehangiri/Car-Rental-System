import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, QComboBox,
    QPushButton, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
import cx_Oracle


class ReturnCarUI(QWidget):
    def __init__(self, user_id, dashboard_window=None):
        super().__init__()
        self.logged_in_user_id = user_id
        self.dashboard_window = dashboard_window
        self.setWindowTitle("🔁 Return a Car")
        self.setGeometry(250, 100, 500, 300)
        self.setStyleSheet("background-color: #1e1e2f; color: white;")
        self.conn = cx_Oracle.connect("FARAZ4", "gudboy", "localhost/XE")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        title = QLabel("🔁 Return a Car")
        title.setFont(QFont("Segoe UI", 16, QFont.Bold))
        title.setStyleSheet("color: #00ffff;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        self.booking_dropdown = QComboBox()
        self.booking_dropdown.setStyleSheet("background-color: #2d2d44; color: white;")
        layout.addWidget(QLabel("Select a Booking to Return:"))
        layout.addWidget(self.booking_dropdown)

        return_btn = QPushButton("Return Selected Car")
        return_btn.setStyleSheet("background-color: #00cc66; padding: 10px; border-radius: 5px;")
        return_btn.clicked.connect(self.return_car)
        layout.addWidget(return_btn)

        back_btn = QPushButton("⬅ Back to Dashboard")
        back_btn.setStyleSheet("background-color: #555555; padding: 10px; border-radius: 5px;")
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)

        self.setLayout(layout)
        self.load_user_bookings()

    def load_user_bookings(self):
        cursor = self.conn.cursor()
        self.booking_dropdown.clear()

        query = """
            SELECT B.BOOKING_ID, B.CAR_ID, B.DRIVER_ID
            FROM BOOKINGS B
            JOIN CARS C ON B.CAR_ID = C.CAR_ID
            WHERE B.USER_ID = :1 AND C.AVAILABILITY = 'no'
        """
        cursor.execute(query, (self.logged_in_user_id,))
        self.bookings = cursor.fetchall()

        for booking_id, car_id, driver_id in self.bookings:
            text = f"Booking #{booking_id} | Car ID: {car_id}" + (f" | Driver ID: {driver_id}" if driver_id else "")
            self.booking_dropdown.addItem(text, (booking_id, car_id, driver_id))

        cursor.close()

    def return_car(self):
        booking_info = self.booking_dropdown.currentData()
        if not booking_info:
            QMessageBox.warning(self, "No Selection", "Please select a booking to return.")
            return

        booking_id = booking_info[0]
        car_id = booking_info[1]
        driver_id = booking_info[2]

        cursor = self.conn.cursor()
        try:
            # Update car availability
            cursor.execute("UPDATE CARS SET AVAILABILITY = 'yes' WHERE CAR_ID = :1", (car_id,))

            # Update driver availability (if applicable)
            if driver_id:
                cursor.execute("UPDATE DRIVERS SET AVAILABILITY = 'yes' WHERE DRIVER_ID = :1", (driver_id,))

            # Delete the booking record
            cursor.execute("DELETE FROM BOOKINGS WHERE BOOKING_ID = :1", (booking_id,))

            self.conn.commit()
            QMessageBox.information(self, "Success", "Car returned successfully and booking removed.")

            # ✅ Refresh dropdown by calling the correct method
            self.load_user_bookings()

        except Exception as e:
            self.conn.rollback()
            QMessageBox.critical(self, "Error", f"Failed to return car:\n{str(e)}")
        finally:
            cursor.close()

    def go_back(self):
        self.close()
        if self.dashboard_window:
            self.dashboard_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    user_id = 5  # test only
    window = ReturnCarUI(user_id)
    window.show()
    sys.exit(app.exec_())
